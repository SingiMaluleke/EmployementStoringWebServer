import React from 'react';

function Home() {
    return (
        <div>
            <h1>Welcome to the Company Portal</h1>
            <p>Select a section from the navigation menu.</p>
        </div>
    );
}

export default Home;