import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Employees.css'; 

function AddEmployee() {
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    gender: '',
    department: '',
    salary: ''
  });

  // Load existing employees
  useEffect(() => {
    axios.get('http://localhost:5000/api/employees')
      .then(res => setEmployees(res.data))
      .catch(err => console.error(err));
  }, []);

  // Add new employee
  const handleSubmit = (e) => {
    e.preventDefault();
    const newEmployee = {
      ...formData,
      id: Date.now(), 
      salary: parseFloat(formData.salary)
    };

    setEmployees(prev => [...prev, newEmployee]);
    setFormData({ name: '', surname: '', gender: '', department: '', salary: '' });
  };

  // Delete employee
  const handleDelete = (id) => {
    const updated = employees.filter(emp => emp.id !== id);
    setEmployees(updated);
  };

  // Clear form
  const handleClear = () => {
    setFormData({ name: '', surname: '', gender: '', department: '', salary: '' });
  };

  return (
    <div className="employees-container">
      <h2>Add New Employee</h2>
      <p>Fill in the details below to add a new employee.</p>
      <form onSubmit={handleSubmit} className="employee-form">
        <input
          type="text"
          placeholder="Name"
          value={formData.name}
          onChange={e => setFormData({ ...formData, name: e.target.value })}
          required
        />

        <input
          type="text"
          placeholder="Surname"
          value={formData.surname}
          onChange={e => setFormData({ ...formData, surname: e.target.value })}
          required
        />

        <select
          value={formData.gender}
          onChange={e => setFormData({ ...formData, gender: e.target.value })}
          required
        >
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>

        <select
          value={formData.department}
          onChange={e => setFormData({ ...formData, department: e.target.value })}
          required
        >
          <option value="">Select Department</option>
          <option value="Engineering">Engineering</option>
          <option value="Marketing">Marketing</option>
          <option value="Finance">Finance</option>
          <option value="HR">HR</option>
          <option value="IT">IT</option>
        </select>

        <input
          type="number"
          placeholder="Salary"
          value={formData.salary}
          onChange={e => setFormData({ ...formData, salary: e.target.value })}
          required
        />

        <button type="submit">Add</button>
        <button type="button" onClick={handleClear}>Clear</button>
      </form>

      <h3>Current Employees</h3>
      <table className="employees-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Gender</th>
            <th>Department</th>
            <th>Salary</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {employees.map(emp => (
            <tr key={emp.id}>
              <td>{emp.name}</td>
              <td>{emp.surname}</td>
              <td>{emp.gender}</td>
              <td>{emp.department}</td>
              <td>{emp.salary.toLocaleString('en-ZA', {
                style: 'currency',
                currency: 'ZAR'
              })}</td>
              <td>
                <button onClick={() => handleDelete(emp.id)} className="delete-btn">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AddEmployee;
